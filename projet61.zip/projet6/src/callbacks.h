#include <gtk/gtk.h>


void on_button_connecter_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);




void
on_button_afficher_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_supprimer_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_modifier_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajouter_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajouter1_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_modifier1_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_retour3_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour2_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);
