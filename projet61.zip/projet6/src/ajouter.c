#include <stdio.h>
#include <string.h>
#include "ajouter.h"

void ajouter(agent p)
{
FILE *f;
f=fopen("agent.txt","a+");
if(f!=NULL)
{ 
fprintf(f,"%s %s %s %d/%d/%d %s %s %s \n",p.cin,p.nom,p.prenom,p.date.jour,p.date.mois,p.date.annee,p.specialite,p.login,p.motdepasse);
fclose(f);
}}
