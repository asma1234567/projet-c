#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include <afficher.h>


enum
{     
      cin,
      nom,
      prenom,
      date,
      specialite,
      login,
      motdepasse,
      COLUMNS
};


void afficher(GtkWidget *treeview)
{
  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GtkTreeIter  iter;

  GtkListStore *store;

  char NOM[30];
  char PRENOM[30];
  char DATE[30];
  char SPECIALITE[30];
  char CIN[30];
  char LOGIN[30];
  char MOTDEPASSE[30];

  FILE *f;
  store=NULL;
  

  store=gtk_tree_view_get_model(treeview);
  if (store==NULL)
  {
      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes("cin",renderer,"text",cin,NULL);
 gtk_tree_view_append_column (GTK_TREE_VIEW(treeview),column);


renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes("nom",renderer,"text",nom,NULL);
 gtk_tree_view_append_column (GTK_TREE_VIEW(treeview),column);


renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",prenom,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(treeview),column);


renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes("date",renderer,"text",date,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(treeview),column);

renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes("specialite",renderer,"text",specialite,NULL);
 gtk_tree_view_append_column (GTK_TREE_VIEW(treeview),column);


renderer = gtk_cell_renderer_text_new();

      column = gtk_tree_view_column_new_with_attributes("login",renderer,"text",login,NULL);
 gtk_tree_view_append_column (GTK_TREE_VIEW(treeview),column);




renderer = gtk_cell_renderer_text_new();

      column = gtk_tree_view_column_new_with_attributes("motdepasse",renderer,"text",motdepasse,NULL);

      gtk_tree_view_append_column (GTK_TREE_VIEW(treeview),column);



      

      store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

      f=fopen("agent.txt","r");
      
      if(f==NULL)
      { return;}
      else
{ 
while(fscanf(f,"%s %s %s %s %s %s %s \n",CIN,NOM,PRENOM,DATE,SPECIALITE,LOGIN,MOTDEPASSE)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,cin,CIN,nom,NOM,prenom,PRENOM,date,DATE,specialite,SPECIALITE,login,LOGIN,motdepasse,MOTDEPASSE,-1);
}
fclose(f);
}
gtk_tree_view_set_model(GTK_TREE_VIEW (treeview), GTK_TREE_MODEL (store));
g_object_unref (store);

}
}
