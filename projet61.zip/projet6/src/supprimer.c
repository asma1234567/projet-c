#include <stdio.h>
#include <string.h>
#include "supprimer.h"
#include <gtk/gtk.h>


void supprimer(char CIN[20])
{
agent1 p;
FILE*f;
    FILE*ftemp;

f=fopen("agent.txt","r");
ftemp=fopen("agent_temp","w");


while(fscanf(f,"%s %s %s %d/%d/%d %s %s %s \n",p.cin,p.nom,p.prenom,&p.date.jour,&p.date.mois,&p.date.annee,p.specialite,p.login,p.motdepasse)!=EOF)
{
    if(strcmp(CIN,p.cin)!=0)
    {
fprintf(ftemp,"%s %s %s %d/%d/%d %s %s %s \n",p.cin,p.nom,p.prenom,p.date.jour,p.date.mois,p.date.annee,p.specialite,p.login,p.motdepasse);
    
}
}
fclose(ftemp);
fclose(f);

remove("agent.txt");
rename("agent_temp","agent.txt");

}

int verif(char x[])
{
agent1 p;

FILE*f;

f=fopen("agent.txt","r");

if(f!=NULL)
{
while(fscanf(f,"%s %s %s %d/%d/%d %s %s %s \n",p.cin,p.nom,p.prenom,&p.date.jour,&p.date.mois,&p.date.annee,p.specialite,p.login,p.motdepasse)!=EOF)
{ if (strcmp(x,p.cin)==0)
{
return 1;
}
}
return 0;
fclose(f);
}
}



agent1 chercher(char x[])
{
agent1 p;
FILE*f;

f=fopen("agent.txt","r");

if(f!=NULL) {

while(fscanf(f,"%s %s %s %d/%d/%d %s %s %s \n",p.cin,p.nom,p.prenom,&p.date.jour,&p.date.mois,&p.date.annee,p.specialite,p.login,p.motdepasse)!=EOF)
{ if (strcmp(x,p.cin)==0)
{
return p;
}
}

fclose(f);


}}

void modifier(agent1 n)
{
FILE*f;
    FILE*ftemp;
    agent1 p;

    f=fopen("agent.txt","r");
ftemp=fopen("agent.tmp","w");
if(f!=NULL)
{

   

while(fscanf(f,"%s %s %s %d %d %d %s %s %s \n",p.cin,p.nom,p.prenom,&p.date.jour,&p.date.mois,&p.date.annee,p.specialite,p.login,p.motdepasse)!=EOF);
{
    if(strcmp(n.cin,p.cin)!=0)
    { fprintf(ftemp,"%s %s %s %d %d %d %s %s %s \n",p.cin,p.nom,p.prenom,p.date.jour,p.date.mois,p.date.annee,p.specialite,p.login,p.motdepasse);

    }
    else{


    fprintf(ftemp,"%s %s %s %d %d %d %s %s %s \n",p.cin,n.nom,n.prenom,n.date.jour,n.date.mois,n.date.annee,p.specialite,n.login,n.motdepasse);
    }
}
fclose(f);
fclose(ftemp);

remove("agent.txt");
rename("agent.tmp","agent.txt");

}

}



