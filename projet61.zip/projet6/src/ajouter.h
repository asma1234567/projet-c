
typedef struct
{
int jour;
int mois;
int annee;
}DATE;



typedef struct 
{
char nom[20];
char prenom[20];
char specialite[20]; 
DATE date;
char cin[20];
char login[20];
char motdepasse[20];
}agent; 

void ajouter(agent p);

 
