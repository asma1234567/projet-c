#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "connecter.h"
#include "afficher.h"
#include "ajouter.h"
#include "supprimer.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void on_button_connecter_clicked (GtkWidget *objet_graphique, gpointer         user_data)
{

GtkWidget *input1=lookup_widget(objet_graphique,"entry_login");
GtkWidget *input2=lookup_widget(objet_graphique,"entry_motdepasse");
GtkWidget *output=lookup_widget(objet_graphique,"labelerreur");
GtkWidget *windo;
GtkWidget *windowadmin;
GtkWidget *erreur;

char login[20];
char motdepasse[20];

int s;


strcpy(login,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(motdepasse,gtk_entry_get_text(GTK_ENTRY(input2)));
        
s=verifier(login,motdepasse);

if (s==-1){
gtk_label_set_text(GTK_LABEL(output),"erreur");
}
else
{

windo=lookup_widget(objet_graphique,"windowlogin");
gtk_widget_destroy(windo);
windowadmin=lookup_widget(objet_graphique,"windowadmin");

windowadmin=create_windowadmin();  
gtk_widget_show(windowadmin);
}

}








void
on_button_afficher_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *windowadmin;
GtkWidget *windowadmin1;
GtkWidget *treeview1;

windowadmin=lookup_widget(objet,"windowadmin");

gtk_widget_destroy(windowadmin);
windowadmin1=lookup_widget(objet,"windowadmin1");
windowadmin1=create_windowadmin1();

gtk_widget_show(windowadmin1);

treeview1=lookup_widget(windowadmin1,"treeview1");

afficher(treeview1);



}


void
on_button_retour_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{ 
     GtkWidget *windowadmin1, *windowadmin ;
     windowadmin1=lookup_widget(objet,"windowadmin1");
     gtk_widget_destroy(windowadmin1);
     windowadmin=create_windowadmin();
     gtk_widget_show(windowadmin);
     

}


void
on_button_supprimer_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
int test;
agent1 p;
char msg[50];

GtkWidget *windowadmin1;

GtkWidget *input1 =lookup_widget(objet,"entry_login");

strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input1)));

GtkWidget *output1 =lookup_widget(objet,"label_msg");


test=verif(p.cin);

if(test==1)
{
p=chercher(p.cin);
 
supprimer(p.cin);

strcpy(msg,"Agent supprimé");
gtk_label_set_text(GTK_LABEL(output1),msg);
}
else
{
strcpy(msg,"identifiant inexistant");
gtk_label_set_text(GTK_LABEL(output1),msg);
}
}




void
on_button_modifier_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
int test;
agent1 p;
char msg[50];

GtkWidget *windowadmin1,*windowmodifier;

GtkWidget *input1 =lookup_widget(objet,"entry_login");

strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input1)));

GtkWidget *output1 =lookup_widget(objet,"label_msg");


test=verif(p.cin);

if(test==1)
{
p=chercher(p.cin);
 
supprimer(p.cin);


     windowadmin1=lookup_widget(objet,"windowadmin1");
     gtk_widget_destroy(windowadmin1);
     windowmodifier=create_windowmodifier();
     gtk_widget_show(windowmodifier);


}
else
{
strcpy(msg,"identifiant inexistant");
gtk_label_set_text(GTK_LABEL(output1),msg);
}


}


void
on_button_ajouter_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
 GtkWidget *windowadmin1, *windowajouter;
     windowadmin1=lookup_widget(objet,"windowadmin1");
     gtk_widget_destroy(windowadmin1);
     windowajouter=create_windowajouter();
     gtk_widget_show(windowajouter);

}


void
on_button_ajouter1_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

agent p;


GtkWidget  *windowajouter,*windowadmin1,*treeview1;


GtkWidget *input1 = lookup_widget(objet_graphique,"entry_nom");
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input1)));

GtkWidget *input2 = lookup_widget(objet_graphique,"entry_prenom");
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));

GtkWidget *input3 = lookup_widget(objet_graphique,"entry_cin");
strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input3)));


GtkWidget *input4 = lookup_widget(objet_graphique,"entry_login");
strcpy(p.login,gtk_entry_get_text(GTK_ENTRY(input4)));

GtkWidget *input5 = lookup_widget(objet_graphique,"entry_motdepasse");
strcpy(p.motdepasse,gtk_entry_get_text(GTK_ENTRY(input5)));

GtkWidget *combobox = lookup_widget(objet_graphique,"combobox1");

strcpy(p.specialite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)));

GtkWidget *jour = lookup_widget(objet_graphique,"spinbutton3");
p.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
GtkWidget *mois = lookup_widget(objet_graphique,"spinbutton4");
p.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
GtkWidget *annee = lookup_widget(objet_graphique,"spinbutton5");
p.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

ajouter(p);


     windowadmin1=lookup_widget(objet_graphique,"windowajouter");
     gtk_widget_destroy(windowajouter);
     windowadmin1=create_windowadmin1();
     gtk_widget_show(windowadmin1);

       treeview1=lookup_widget(windowadmin1,"treeview1");

afficher(treeview1);
}


void
on_button_modifier1_clicked            (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
agent p;


GtkWidget  *windowmodifier,*windowadmin1,*treeview1;


GtkWidget *input1 = lookup_widget(objet_graphique,"entry_nom");
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input1)));

GtkWidget *input2 = lookup_widget(objet_graphique,"entry_prenom");
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));

GtkWidget *input3 = lookup_widget(objet_graphique,"entry_cin");
strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input3)));


GtkWidget *input4 = lookup_widget(objet_graphique,"entry_login");
strcpy(p.login,gtk_entry_get_text(GTK_ENTRY(input4)));

GtkWidget *input5 = lookup_widget(objet_graphique,"entry_motdepasse");
strcpy(p.motdepasse,gtk_entry_get_text(GTK_ENTRY(input5)));

GtkWidget *combobox = lookup_widget(objet_graphique,"combobox1");

strcpy(p.specialite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)));

GtkWidget *jour = lookup_widget(objet_graphique,"spinbutton3");
p.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
GtkWidget *mois = lookup_widget(objet_graphique,"spinbutton4");
p.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
GtkWidget *annee = lookup_widget(objet_graphique,"spinbutton5");
p.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

ajouter(p);


 
     windowadmin1=lookup_widget(objet_graphique,"windowmodifier");
     gtk_widget_destroy(windowmodifier);
     windowadmin1=create_windowadmin1();
     gtk_widget_show(windowadmin1);
       treeview1=lookup_widget(windowadmin1,"treeview1");

afficher(treeview1);

}


void
on_button_retour3_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
 GtkWidget *windowmodifier, *windowadmin1,*treeview1;
     windowadmin1=lookup_widget(objet,"windowmodifier");
     gtk_widget_destroy(windowmodifier);
     windowadmin1=create_windowadmin1();
     gtk_widget_show(windowadmin1);

          treeview1=lookup_widget(windowadmin1,"treeview1");

afficher(treeview1);
     

}


void
on_button_retour2_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
 GtkWidget *windowajouter, *windowadmin1,*treeview1;
     windowadmin1=lookup_widget(objet,"windowajouter");
     gtk_widget_destroy(windowajouter);
     windowadmin1=create_windowadmin1();
     gtk_widget_show(windowadmin1);
     treeview1=lookup_widget(windowadmin1,"treeview1");

afficher(treeview1);

}

