typedef struct
{
char CIN[20];
char NOM[20];
char PRENOM[20];
char DATE[20];
char SPECIALITE[20];
char LOGIN[20];
char MOTDEPASSE[20];
}personne;
void afficher(GtkWidget *treeview);
