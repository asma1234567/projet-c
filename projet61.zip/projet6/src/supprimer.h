#include <gtk/gtk.h>
typedef struct
{
int jour;
int mois;
int annee;
}DATE1;



typedef struct 
{
char nom[20];
char prenom[20];
char specialite[20]; 
DATE1 date;
char cin[20];
char login[20];
char motdepasse[20];
}agent1; 

void supprimer(char login[20]);
int verif(char x[]);
agent1 chercher(char x[]);
void modifier(agent1 n);
