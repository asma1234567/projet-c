#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>




int verifier (char login[50], char motdepasse[50]) 
{
FILE*f;
        	
        int role;
	
	char username[50];
	char password[30];
	
    	

	f=fopen("users.txt","r");
	while(fscanf(f,"%s %s %d \n",username,password,&role)!=EOF)  
        {
		if (strcmp(login,username)==0 && strcmp(motdepasse,password)==0)
                	return role;
                
		else                  
			 return -1; 
        }
 fclose(f);
 }
 









      









