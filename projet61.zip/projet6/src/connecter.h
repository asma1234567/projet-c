#include <gtk/gtk.h>
int verifier(char login[50], char motdepasse[50]);



